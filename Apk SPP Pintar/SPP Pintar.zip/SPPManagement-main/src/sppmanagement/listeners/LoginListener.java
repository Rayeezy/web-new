/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sppmanagement.listeners;

/**
 *
 * @author ASTANEW2
 */
public interface LoginListener {
    void onSuccess();
    void onFailure();
}
